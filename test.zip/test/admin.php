<?php
session_start();

// Check if the user is logged in as an admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Portal - Student Management System</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* Global Styles */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            background-color: #f0f4f8;
            color: #333;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        /* Header Section */
        header {
            background-color: #0047ab;
            color: white;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }

        header h1 {
            margin: 0;
            font-size: 2rem;
        }

        header p {
            margin: 10px 0 0;
        }

        /* Navigation Menu */
        nav {
            background-color: #003366;
            padding: 10px 0;
            display: flex;
            justify-content: center;
            gap: 20px;
        }

        nav a {
            color: white;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: #00509e;
        }

        /* Main Content Section */
        .content {
            max-width: 1000px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .content h2 {
            color: #0047ab;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
            margin-bottom: 20px;
            font-size: 1.8rem;
        }

        .content p {
            margin-bottom: 20px;
        }

        /* Form Styling */
        form label {
            font-weight: bold;
            display: block;
            margin: 10px 0 5px;
        }

        form input, form select, form button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        form button {
            background-color: #0047ab;
            color: white;
            font-weight: bold;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        form button:hover {
            background-color: #002e73;
        }

        /* Footer Section */
        footer {
            background-color: #003366;
            color: white;
            text-align: center;
            padding: 15px 0;
            margin-top: 20px;
        }

        /* Hidden Sections */
        .section {
            display: none;
        }

        .section.active {
            display: block;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <h1>Welcome to the Admin Portal</h1>
        <p>Manage Students, Courses, and System Settings</p>
    </header>

    <!-- Navigation -->
    <nav>
        <a href="#" onclick="showSection('adminDashboard')">Dashboard</a>
        <a href="#" onclick="showSection('addStudent')">Add Student</a>
        <a href="#" onclick="showSection('enrollStudent')">Enroll Student</a>
        <a href="#" onclick="showSection('deleteStudent')">Delete Student</a>
        <a href="home.html?logout=true">Logout</a>
    </nav>

    <!-- Main Content -->
    <div class="content">
        <!-- Dashboard Section -->
        <section id="adminDashboard" class="section active">
            <h2>Admin Dashboard</h2>
            <p>Welcome to the admin panel. Use the menu above to navigate through different functionalities.</p>
        </section>

        <!-- Add Student Section -->
        <section id="addStudent" class="section">
            <h2>Add New Student</h2>
            <form method="POST" action="submit_student.php">
                <label for="studentName">Student Name</label>
                <input type="text" id="studentName" name="name" placeholder="Enter student name" required>
                
                <label for="studentEmail">Email</label>
                <input type="email" id="studentEmail" name="email" placeholder="Enter student email" required>

                <button type="submit">Add Student</button>
            </form>
        </section>

        <section id="enrollStudent" class="section">
    <h2>Enroll Student in Courses</h2>
    <form method="POST" action="submit_student.php">
        <label for="selectStudent">Select Student</label>
        <select id="selectStudent" name="student">
            <option value="joseph ogugua">Joseph Ogugua</option>
            <option value="godsent">Godsent</option>
<option value="kindNana">kindNana</option>
        </select>

        <label>Select Courses</label>
        <input type="checkbox" id="course1" name="courses[]" value="Java Programming"> Java Programming<br>
        <input type="checkbox" id="course2" name="courses[]" value="Database Systems"> Database Systems<br>
        <input type="checkbox" id="course3" name="courses[]" value="Web Development"> Web Development<br>

        <button type="submit">Submit</button>
    </form>
</section>
       

        <!-- Delete Student Section -->
        <section id="deleteStudent" class="section">
            <h2>Delete Student</h2>
            <p>Select a student to delete:</p>
            <ul>
                <li>joseph ogugua
 <button>Delete</button></li>
                <li>Godsent <button>Delete</button></li>
            </ul>
        </section>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy2024 BrightMind Online | Contact: info@brightmindonline.com | Terms of Service</p>
    </footer>

    <!-- JavaScript -->
    <script>
        function showSection(sectionId) {
            document.querySelectorAll(".section").forEach(section => {
                section.classList.remove("active");
            });
            document.getElementById(sectionId).classList.add("active");
        }
    </script>
</body>
</html>