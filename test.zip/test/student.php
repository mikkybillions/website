<?php
session_start();

// Check if the user is logged in as a student
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - Student Management System</title>
    <style>
        /* Base Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body Styling */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            background-color: #f5f8fa;
            color: #333;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Header Banner */
        .banner {
            background-color: #0047ab;
            color: white;
            text-align: center;
            padding: 40px 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .banner h1 {
            font-size: 2.5rem;
        }

        .banner p {
            margin-top: 10px;
            font-size: 1.2rem;
        }

        /* Main Content */
        .content {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #0047ab;
            border-bottom: 2px solid #eee;
            margin-bottom: 15px;
            padding-bottom: 5px;
            font-size: 1.8rem;
        }

        p {
            margin-bottom: 15px;
        }

        /* Course and Material Lists */
        ul {
            list-style: none;
            padding: 0;
        }

        ul li {
            padding: 10px;
            margin: 5px 0;
            background-color: #f0f8ff;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        ul li a {
            color: #0047ab;
            font-weight: bold;
            text-decoration: none;
        }

        ul li a:hover {
            text-decoration: underline;
        }

        /* Navigation */
        nav {
            margin: 20px 0;
            text-align: center;
        }

        nav a {
            color: #0047ab;
            margin: 0 15px;
            font-weight: bold;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            border: 1px solid transparent;
            transition: background-color 0.3s, border-color 0.3s;
        }

        nav a:hover {
            background-color: #e6f0ff;
            border-color: #0047ab;
        }

        /* Settings Form */
        .settings-form label {
            display: block;
            font-weight: bold;
            margin-top: 10px;
        }

        .settings-form input, .settings-form button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .settings-form button {
            background-color: #0047ab;
            color: white;
            font-weight: bold;
            cursor: pointer;
            border: none;
        }

        .settings-form button:hover {
            background-color: #003366;
        }

        /* Footer */
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 15px 0;
            margin-top: auto;
        }
    </style>
</head>
<body>
    <!-- Banner -->
    <header class="banner">
        <h1>Welcome to Your Student Dashboard</h1>
        <p>Access your courses, materials, and settings below.</p>
    </header>

    <!-- Navigation -->
    <nav>
        <a href="#dashboard" onclick="showSection('dashboard')">Dashboard</a>
        <a href="#settings" onclick="showSection('settings')">Settings</a>
        <a href="home.html?logout=true">Logout</a>
    </nav>

    <!-- Main Content -->
    <div class="content">
        <!-- Dashboard Section -->
        <section id="dashboard" class="section active">
            <h2>Your Courses</h2>
            <ul>
                <li><strong>Java Programming:</strong> Monday & Wednesday, 10:00 AM - 12:00 PM</li>
                <li><strong>Database Development:</strong> Tuesday & Thursday, 1:00 PM - 3:00 PM</li>
                <li><strong>Web Development:</strong> Friday, 2:00 PM - 5:00 PM</li>
            </ul>

            <h2>Course Materials</h2>
            <ul>
                <li><strong>Java Programming:</strong> <a href="#">Introduction to Programming</a></li>
                <li><strong>Database Development:</strong> <a href="#">Database Fundamentals</a></li>
                <li><strong>Web Development:</strong> <a href="#">HTML Basics</a></li>
            </ul>
        </section>

        <!-- Settings Section -->
        <section id="settings" class="section">
            <h2>Settings</h2>
            <form class="settings-form" action="change_password.php" method="POST">
    <label for="currentPassword">Current Password</label>
    <input type="password" id="currentPassword" name="currentPassword" placeholder="Enter current password" required>

    <label for="newPassword">New Password</label>
    <input type="password" id="newPassword" name="newPassword" placeholder="Enter new password" required>

    <label for="confirmPassword">Confirm New Password</label>
    <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm new password" required>

    <button type="submit">Change Password</button>
</form>
        </section>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy2024 BrightMind Online | Contact: info@brightmindonline.com | Terms of Service</p>
    </footer>

    <!-- JavaScript -->
    <script>
        function showSection(sectionId) {
            document.querySelectorAll('.section').forEach(section => {
                section.classList.remove('active');
            });
            document.getElementById(sectionId).classList.add('active');
        }
    </script>
</body>
</html>