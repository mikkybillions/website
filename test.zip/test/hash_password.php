<?php
// Example user input
$username = 'king';
$email = 'king@gmail.com';
$plainPassword = '-2652848';  // The user's password

// Hash the password before storing it
$hashedPassword = password_hash($plainPassword, PASSWORD_BCRYPT);

// Database connection (replace with your connection details)
$servername = "localhost";
$username = "root";
$dbname = "tests"; // Database name
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error); // If connection fails, stop further execution
}
echo "Connected successfully"; // This should be inside the if block as a success message

// Prepare SQL query to insert data (excluding the `id` column as it auto-increments)
$sql = "INSERT INTO `app_users` (username, email, password) 
        VALUES (?, ?, ?)";

// Prepare and bind
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $username, $email, $hashedPassword);

// Execute the query
if ($stmt->execute()) {
    echo "User added successfully!";
} else {
    echo "Error: " . $stmt->error;
}

// Close connection
$stmt->close();
$conn->close();
?>