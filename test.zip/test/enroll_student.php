<?php
require 'db.php'; // Include the database connection file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $studentId = intval($_POST['student_id']); // Get student ID from form submission
    $courses = $_POST['courses']; // Get selected courses (as an array)

    if (!empty($courses)) {
        foreach ($courses as $courseId) {
            $query = "INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ii", $studentId, $courseId);
            $stmt->execute();
        }
        echo "Student enrolled in selected courses successfully!";
    } else {
        echo "No courses selected for enrollment.";
    }

    $stmt->close();
    $conn->close();
}
?>