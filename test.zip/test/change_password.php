<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo "Session user_id is not set.";
    
} else {
    echo "User ID in session: " . $_SESSION['user_id'];
}
// Get the POST data from the form
$currentPassword = $_POST['currentPassword'];
$newPassword = $_POST['newPassword'];
$confirmPassword = $_POST['confirmPassword'];

// Validate the input
if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
    die("All fields are required.");
}

if ($newPassword !== $confirmPassword) {
    die("New passwords do not match.");
}

// Fetch the current password hash from the database
$userId = $_SESSION['user_id'];
$sql = "SELECT password FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("User not found.");
}

$row = $result->fetch_assoc();
$hashedPassword = $row['password'];

// Verify the current password
if (!password_verify($currentPassword, $hashedPassword)) {
    die("Current password is incorrect.");
}

// Hash the new password
$newHashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);

// Update the password in the database
$updateSql = "UPDATE users SET password = ? WHERE id = ?";
$updateStmt = $conn->prepare($updateSql);
$updateStmt->bind_param("si", $newHashedPassword, $userId);

if ($updateStmt->execute()) {
    echo "Password changed successfully.";
} else {
    echo "Error updating password.";
}
?>
