<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    
    <!-- Internal CSS -->
    <style>
        /* Basic Styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        /* Container for Dashboard Page */
        .dashboard-container {
            width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        /* Header Section */
        .header {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            font-size: 24px;
        }

        /* Courses List */
        .courses {
            text-align: left;
            margin: 20px 0;
        }

        .course-item {
            padding: 10px;
            margin: 5px 0;
            background-color: #f1f1f1;
            border-radius: 4px;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        /* Footer */
        .footer {
            background-color: #333;
            color: white;
            padding: 10px;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- Header Section -->
    <div class="header">
        Student Dashboard
    </div>

    <!-- Main Container for Dashboard -->
    <div class="dashboard-container">
        <!-- Courses Materials Section -->
        <h2>Course Materials</h2>
        <div class="courses">
            <div class="course-item">Introduction to Computer Science</div>
            <div class="course-item">Data Structures</div>
            <div class="course-item">Algorithms</div>
            <div class="course-item">Database Systems</div>
            <div class="course-item">Operating Systems</div>
        </div>

        <!-- Settings Button -->
        <button onclick="window.location.href='settings.php'">Settings</button>
    </div>

    <!-- Footer Section -->
    <div class="footer">
        &copy; <?php echo date("Y"); ?> Student Dashboard. All rights reserved.
    </div>
</body>
</html>
