<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header-title">Student Dashboard</div>
        <a href="settings.php" class="settings-button">Settings</a>
    </header>

    <main>
        <h2>Course Materials</h2>
        <section class="course-materials">
            <div class="course-item">Computer Science 101 - Introduction to Programming</div>
            <div class="course-item">Computer Science 201 - Data Structures</div>
            <div class="course-item">Computer Science 301 - Algorithms</div>
            <div class="course-item">Computer Science 401 - Operating Systems</div>
            <div class="course-item">Computer Science 501 - Machine Learning</div>
        </section>
    </main>

    <footer>
        <p>Footer</p>
    </footer>
</body>
</html>
