<?php
require 'db.php'; // Include the database connection file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $studentId = intval($_POST['student_id']); // Get student ID from form submission

    // Delete student from the database
    $query = "DELETE FROM students WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $studentId);

    if ($stmt->execute()) {
        echo "Student deleted successfully!";
    } else {
        echo "Error deleting student: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>