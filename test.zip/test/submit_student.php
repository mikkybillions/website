<?php
// Database connection
$servername = "localhost";
$username = "root"; // Adjust based on your database username
$password = ""; // Adjust based on your database password
$dbname = "tests"; // Your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate required fields
    if (empty($_POST['student']) || empty($_POST['courses'])) {
        echo "All fields are required!";
        exit;
    }

    // Retrieve the form data
    $student = $_POST['student'];
    $courses = $_POST['courses']; // This will be an array of selected courses

    // Insert the student into the `students` table if it doesn't already exist
    $stmt = $conn->prepare("SELECT id FROM students WHERE name = ?");
    $stmt->bind_param("s", $student);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $stmt = $conn->prepare("INSERT INTO students (name) VALUES (?)");
        $stmt->bind_param("s", $student);
        $stmt->execute();
        $student_id = $stmt->insert_id; // Get the ID of the inserted student
    } else {
        $row = $result->fetch_assoc();
        $student_id = $row['id']; // Use the existing student ID
    }

    // Insert enrollments into the `enrollments` table
    foreach ($courses as $course) {
        // Get the course ID from the `courses` table
        $stmt = $conn->prepare("SELECT id FROM courses WHERE name = ?");
        $stmt->bind_param("s", $course);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $course_id = $row['id'];

            // Insert into the `enrollments` table
            $stmt = $conn->prepare("INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)");
            $stmt->bind_param("ii", $student_id, $course_id);
            $stmt->execute();
        }
    }

    echo "Student: " . htmlspecialchars($student) . "<br>";
    echo "Enrolled in courses: <br>";
    foreach ($courses as $course) {
        echo "- " . htmlspecialchars($course) . "<br>";
    }
}

$conn->close();
?>