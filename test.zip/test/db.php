<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tests"; // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Connection is successful. No need to echo messages here.
?>